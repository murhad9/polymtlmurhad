﻿////////////////////////////////////////////////////////////////////////////////
/// \file   main.cpp
/// \author Charles Hosson
///
/// Fonction principale du programme.
////////////////////////////////////////////////////////////////////////////////


#pragma region "Inclusions" //{

#include <ciso646>
#include <cstddef>
#include <cstdint>

#include <iomanip>
#include <iostream>
#include <fstream>
#include <string>

#include "cppitertools/range.hpp"

#include "debogageMemoire.hpp"
#include "unicode.hpp"

#include "constantes.hpp"
#include "utf8.hpp"
#include "utf16.hpp"


using namespace std;
using namespace iter;

#pragma endregion //}


void exempleAffichageUnicode ( );


int main ( )
{
	initDebogageMemoire(); // Affichera dans la "Sortie" de VisualStudio les fuites de mémoire.
	initUnicode();
	
	exempleAffichageUnicode(); // TODO: à enlever quand l'affichage est correct.
	
	const string nomsFichiersEntree[3] = {"TroisMousquetaires.txt",
	                                      "CaracteresAnciens.txt",
	                                      "Katyusha.txt"};
	const string nomsFichiersSortieUtf16[3] = {"TroisMousquetaires_UTF-16.txt",
	                                           "CaracteresAnciens_UTF-16.txt",
	                                           "Katyusha_UTF-16.txt"};
	const string nomsFichiersSortieUtf8[3]  = {"TroisMousquetaires_UTF-8.txt",
	                                           "CaracteresAnciens_UTF-8.txt",
	                                           "Katyusha_UTF-8.txt"};
	
	// TODO: Lire chaque fichier (en UTF-8), le convertir en UTF-16 puis l'écrire
	//       dans un fichier avec le nom correspondant dans nomsFichiersSortieUtf16.
	//       N'oubliez pas le Byte Order Mark qui est sur deux octets.
	
	// TODO: Lire chaque fichier précédement créés en UTF-16, puis les retraduire
	//       en UTF-8 dans un fichier avec le nom correspondant dans nomsFichiersSortieUtf8.
	//       Faites attention de sauter le BOM (deux octets) en lisant les caractères.
	
	return 0;
}


void exempleAffichageUnicode ( )
{
	// Après avoir initialisé Unicode, vous devez absolument utiliser wcout au lieu de cout.  L'utilisation de cout vous donnera une erreur de "symbole ambigu".
	// Vous pouvez tout de même utiliser des chaînes de caractères non Unicode et les afficher sur wcout.

	// Exemples de chaînes C non Unicode:
	static const char texteNonUnicode[] = "Un texte pas Unicode permet l'affichage des caractères Latin-1, àâéèêïùç...\n";
	wcout << "Une chaine de 'char' est considérée en Latin-1 (pas Unicode):" << endl
	      << texteNonUnicode << endl;
	
	// Exemples de chaînes C Unicode, noter l'utilisation de wchar_t (un caractère Unicode sur 16 bits) au lieu de char (un caractère sur 8 bits), et l'utilisation du L devant les guillemets:
	// (si vous oubliez le L et que vous utilisez des caractères spéciaux, vous aurez l'avertissement "le caractère ... ne peut pas être représenté dans la page de codes actuelle")
	static const wchar_t texteUnicode[] = L"Russe: Добрый день\nGrec: Γεια σας\nTeintes de gris: ░▒▓█\n";
	wcout << L"Une chaine de 'wchar_t' est Unicode et permet les caractères plus spéciaux ♪♫:" << endl
	      << texteUnicode << endl;
	
	// Exemple de string (pas Unicode) et wstring (Unicode):
	static const string stringNonUnicode = "Une string avec caractères Latin-1.";
	static const wstring stringUnicode = L"Une string Unicode ░▒▓█♪♫.";
	wcout << stringNonUnicode << endl // Nous avons fourni une fonction qui permet d'afficher des 'string' sur wcout.
	      << stringUnicode << endl;
	
	// Vous pouvez utilise cin comme d'habitude; ce programme le ne configure pas pour être en unicode.
}

