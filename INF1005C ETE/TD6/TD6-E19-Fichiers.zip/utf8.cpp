﻿////////////////////////////////////////////////////////////////////////////////
/// N'OUBLIEZ PAS VOS ENTÊTES DE FICHIER!
////////////////////////////////////////////////////////////////////////////////


#pragma region "Inclusions" //{

#include <ciso646>
#include <cstddef>
#include <cstdint>

#include <cmath>
#include <string>

#include "cppitertools/range.hpp"

#include "constantes.hpp"
#include "utf16.hpp"

#include "utf8.hpp"


using namespace std;
using namespace iter;

#pragma endregion //}


#pragma region "Définitions" //{

#pragma region "Fonctions" //{

int
calculerNbOctetsEncodageUtf8 ( uint32_t pointCode )
{
	// TODO: Compter le nombre de bits significatifs du point de code.
	//       On veut les bits avant que tout le reste soit à 0.
	//       Par exemple, le nombre 0b01011010 a 7 bits significatifs.
	//       Autre exemple, le nombre 0b00000010 a 2 bits significatifs.
	
	// TODO: Déterminer le nombre d'octets nécessaire à l'encodage à partir du nb de
	//       bits à encoder calculé précédemment (voir tableau dans l'énoncé ou sur Wikipedia).
	
	// TODO: Retourner le nombre d'octets nécessaire

	return {}; // Retour bidon pour que ça compile, à enlever quand vous avez fait la fonction.
}


uint8_t
calculerPrefixePremierOctetUtf8 ( int nbOctetsEncodage )
{
	// TODO: Déterminer et retourner le préfixe du premier octet selon le nombre d'octets de l'encodage.
	//       Voir tableau (la colonne Octet 1) et page Wiki.
	
	return {}; // Retour bidon pour que ça compile, à enlever quand vous avez fait la fonction.
}


uint32_t
calculerPointDeCodeUtf8 ( const uint8_t* sequenceUtf8, int& nbOctetsTraites )
{
	uint32_t resultat = INVALIDE;
	nbOctetsTraites = 0;
	
	// TODO: Si le premier octet de la séquence est en ASCII (< 0x80), retourner
	//       le premier octet et mettre 1 dans nbOctetsTraites.
	// TODO: Sinon :
		// TODO: Déterminer le nombre d'octets encodés pour le caractère. Il faut
		//       compter le nombre de bits à 1 avant le premier 0 en partant du plus
		//       haut ordre.
		//       Donc, si le premier octet est de la forme 1110xxxx, alors il faut
		//       trois octets (incluant le premier) pour encoder le caractère.
		
		// TODO: Extraire les bits de code du premier et les affecter au résultat.
		
		// TODO: Initialiser nbOctetsTraites à 1
		// TODO: Pour chaque octet *SUIVANT* du caractère :
			// TODO: Incrémenter nbOctetsTraites.
			
			// TODO: Si l'octet n'est pas de la forme 10xxxxxx, affecter INVALIDE
			//       Au résultat et quitter la boucle.
			
			// TODO: Faire un décalage à gauche de six bits du résultat et y ajouter
			//       les six bits faibles de l'octet courant.
	
	return resultat;
}


void
encoderCaractereUtf8 ( uint32_t pointCode, string& resultat )
{
	// TODO: Si le point de code est en ASCII (< 0x80), l'ajouter (push_back()) au résultat en convertissant en char.
	// TODO: Sinon :
		// TODO: Compter le nombre de bits significatifs du point de code.
		
		// TODO: Déterminer le nombre d'octets nécessaire à l'encodage (tableau dans l'énoncé ou sur Wikipedia).
		
		// TODO: Déterminer le préfixe du premier octet. Voir tableau et page Wiki.
		
		// TODO: Déclarer un tableau de 4 octets (uint8_t).
		
		// TODO: Pour chaque octet sauf le premier, extraire les 6 bits faibles du
		//       point de code et les ajouter comme octet au tableau ave le préfixe 10xxxxxx,
		//       puis décaler le point de code de 6 bits.
		
		// TODO: Ajouter au tableau l'octet avec les bits restant et le préfixe
		//       précédemment déterminé.
		
		// TODO: Ajouter à la string les octets dans l'ordre inverse qu'il viennent
		//       d'être calculés.
}


string
convertirStringVersUtf8 ( const u16string& str )
{
	string resultat;
	
	// TODO: Tant qu'il reste des codets dans str :
		// TODO: Calculer le point de code du caractère courant (fonction précédemment
		//       définie) et sauter le nombre de codet indiqué par nbCodetTraites (2e paramètre).
		
		// TODO: Si le point de code n'est pas invalide, l'encoder en UTF-8 dans la string de résultat.
	
	return resultat;
}

#pragma endregion //}

#pragma endregion //}

